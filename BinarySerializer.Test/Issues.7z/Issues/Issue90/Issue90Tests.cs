﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BinarySerialization.Test.Issues.Issue90
{
    [TestClass()]
    public class Issue90Tests : TestBase
    {
        [TestMethod()]
        public void RoundtripTest()
        {
            var expected = new TxpTextureAtlas
            {
                Textures =
                [
                    new() {
                        Mipmaps =
                        [
                            new()
                        ],
                        OffsetTable = [0]
                    }
                ],
                OffsetTable = [0]
            };

            _ = Roundtrip(expected);
        }
    }
}
