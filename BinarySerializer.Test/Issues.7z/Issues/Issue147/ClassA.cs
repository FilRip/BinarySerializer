﻿namespace BinarySerialization.Test.Issues.Issue147
{
    class ClassA
    {
#pragma warning disable CS0649
        public int count;
#pragma warning restore CS0649
    }
}