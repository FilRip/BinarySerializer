﻿using System;

namespace BinarySerialization.Test.Issues.Issue21
{
    public class FailingClass
    {
        [FieldOrder(0)]
        public byte EncodedDataType { get; set; }

#pragma warning disable CA1822 // Marquer les membres comme étant static
        [Ignore]
        public Type DataType => typeof(bool);
#pragma warning restore CA1822 // Marquer les membres comme étant static
    }
}