﻿namespace BinarySerialization.Test.Issues.Issue140
{
    public interface ILabel { }
}