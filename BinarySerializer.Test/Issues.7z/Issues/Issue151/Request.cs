﻿namespace BinarySerialization.Test.Issues.Issue151
{
    public class Request : Payload
    {
        [FieldOrder(0)]
        public byte[] EID { get; set; } // Size is equal to PayloadLength 
    }
}