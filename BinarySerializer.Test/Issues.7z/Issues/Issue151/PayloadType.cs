﻿namespace BinarySerialization.Test.Issues.Issue151
{
    public enum PayloadType
    {
        GenericNACK,
        Request,
        UserData
    }
}