﻿namespace BinarySerialization.Test.Issues.Issue225
{
    public class EmptyDescriptorDataBlock : ValueWithDescriptorDataBlock { }
}