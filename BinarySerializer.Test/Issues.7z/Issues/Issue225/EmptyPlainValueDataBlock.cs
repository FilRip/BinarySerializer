﻿namespace BinarySerialization.Test.Issues.Issue225
{
    public class EmptyPlainValueDataBlock : PlainValueDataBlock { }
}