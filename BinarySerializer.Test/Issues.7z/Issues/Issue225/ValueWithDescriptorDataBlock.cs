﻿namespace BinarySerialization.Test.Issues.Issue225
{
#pragma warning disable S2094 // Classes should not be empty
    public abstract class ValueWithDescriptorDataBlock { }
#pragma warning restore S2094 // Classes should not be empty
}