﻿using System.Collections.Generic;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BinarySerialization.Test.Issues.Issue61
{
    [TestClass()]
    public class Issue61Tests : TestBase
    {
        [TestMethod()]
        public void ListOfObjectsTest()
        {
            var expected = new List<Message>
            {
                new() {
                    Data = [0x0, 0x0, 0x0, 0x0]
                }
            };

            var actual = Roundtrip(expected);
            Assert.AreEqual(1, actual.Count);
        }
    }
}
