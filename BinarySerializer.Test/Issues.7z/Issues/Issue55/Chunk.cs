namespace BinarySerialization.Test.Issues.Issue55
{
#pragma warning disable S2094 // Classes should not be empty
    public class Chunk { }
#pragma warning restore S2094 // Classes should not be empty
}