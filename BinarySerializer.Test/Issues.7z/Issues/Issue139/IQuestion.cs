﻿namespace BinarySerialization.Test.Issues.Issue139
{
    public interface IQuestion
    {
    }
}