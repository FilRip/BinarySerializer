﻿using System.Diagnostics;
using System.IO;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BinarySerialization.Test.Issues.Issue38
{
    [TestClass()]
    public class Issue38Tests() : TestBase(false)
    {
        [TestMethod()]
        public void ConstructOnceTest()
        {
            var expected = new ConstructOnceClass();
            Roundtrip(expected);

            // 2 because : One time when instanciate (first line of this method) and a second time for deserializing (called by Roundtrip)
            Assert.AreEqual(2, ConstructOnceClass.Count);
        }

        [TestMethod()]
        public void DeserializeMessageTest()
        {
            var serializer = new BinarySerializer { Endianness = BinarySerialization.Endianness.Little };
            serializer.MemberDeserializing +=
                (sender, args) => { Debug.WriteLine($"Deserializing {args.MemberName}, stream offset {args.Offset}"); };

            serializer.MemberDeserialized +=
                (sender, args) =>
                {
                    Debug.WriteLine($"Deserialized {args.MemberName}, ({args.Value ?? "null"}), stream offset {args.Offset}");
                };
            var inBytes = new byte[]
            {
                0x02, 0x00, 0x78, 0xFF, 0x00, 0x00, 0x30, 0x60, 0x03, 0x01
            };

            using var stream = new MemoryStream(inBytes);
            var actualObj = serializer.Deserialize<MachineState1>(stream);
            Assert.IsNotNull(actualObj);
            Assert.AreEqual(2, actualObj.PosDataCnt);
            Assert.AreEqual(65400u, actualObj.PosData[0].Address);
            Assert.AreEqual(16998448u, actualObj.PosData[1].Address);
        }
    }
}