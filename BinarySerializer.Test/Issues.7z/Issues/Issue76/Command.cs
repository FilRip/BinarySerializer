﻿namespace BinarySerialization.Test.Issues.Issue76
{
    public abstract class Command
    {
    }
}