﻿namespace BinarySerialization.Test.Issues.Issue76
{
    public enum UserLevel : byte
    {
        AuthorizedClient = 0x3
    }
}