﻿namespace BinarySerialization.Test.Issues.Issue50
{
    public enum PlcPayloadType : uint
    {
        Undefined = 0,

        Value1 = 130,

        Value2 = 131,

        Value3 = 142,

        Value4 = 306,

        Value5 = 307
    }
}