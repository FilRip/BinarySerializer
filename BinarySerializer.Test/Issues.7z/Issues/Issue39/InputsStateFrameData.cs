﻿namespace BinarySerialization.Test.Issues.Issue39
{
    public class InputsStateFrameData(bool[] inputs)
    {
        [FieldCount(16)]
        public bool[] Inputs { get; } = inputs;
    }
}