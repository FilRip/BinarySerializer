﻿namespace BinarySerialization.Test.Issues.Issue12
{
#pragma warning disable S2094 // Classes should not be empty
    public abstract class Chunk
    {
    }
#pragma warning restore S2094 // Classes should not be empty
}