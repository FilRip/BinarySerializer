﻿namespace BinarySerialization.Test.Issues.Issue12
{
    public class ParmChunk : Chunk
    {
        public string Stuff { get; set; }
    }
}