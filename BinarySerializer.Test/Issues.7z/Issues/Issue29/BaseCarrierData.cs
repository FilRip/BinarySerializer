﻿namespace BinarySerialization.Test.Issues.Issue29
{
#pragma warning disable S2094 // Classes should not be empty
    public class BaseCarrierData
    {
    }
#pragma warning restore S2094 // Classes should not be empty
}