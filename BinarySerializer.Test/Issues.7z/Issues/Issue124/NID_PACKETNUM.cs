﻿namespace BinarySerialization.Test.Issues.Issue124
{
    public enum NID_PACKETNUM
    {
        PACKET1,
        PACKETN
    }
}