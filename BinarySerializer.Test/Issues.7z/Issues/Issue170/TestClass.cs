﻿namespace BinarySerialization.Test.Issues.Issue170
{
    using BinarySerialization;

    class TestClass
    {
        [FieldOrder(0)]
        [SubtypeDefault(typeof(IPAddressEx))]
        public IIPAddressEx I { get; set; } = new IPAddressEx();

        [FieldOrder(1)]
        [SubtypeDefault(typeof(IPEndPointEx))]
        public IIPEndPointEx EndPoint { get; set; } = new IPEndPointEx();
    }
}
